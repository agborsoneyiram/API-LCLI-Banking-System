package apexbank.services;

import java.util.Scanner;

import apexbank.models.Account;

public class UserService {

    public static void depositAmount(Scanner scanner) {
        System.out.print("Enter Account Number: ");
        scanner.nextLine();
        String accNumber = BankService.readValidString(scanner);

        Account account = BankService.findAccount(accNumber);

        if (account == null) {
            System.out.println("Account not found.");
            return;
        }
        int attempts = 0;
        boolean isCorrect = false;

        while (attempts < 3) {
            System.out.print("Enter your PIN: ");
            int enteredPin = scanner.nextInt();

            if (enteredPin == account.getPincode()) {
                isCorrect = true;
                break;
            } else {
                attempts++;
                System.out.println("Incorrect! Attempts used: " + attempts + "/3");
            }
        }

        if (isCorrect == false) {
            System.out.println("YOU FRAUD! Access blocked.");
            return; // Kill the method here
        }

        System.out.print("Enter amount to deposit: ");
        double amount = scanner.nextDouble();

        account.deposit(amount);
        System.out.println("Success! New balance: GHS " + account.checkBalance());
    }

    
    public static void withdrawAmount(Scanner scanner) {
        System.out.print("Enter Account Number: ");
        scanner.nextLine();
        String accNumber = BankService.readValidString(scanner);

        Account account = BankService.findAccount(accNumber);

        if (account == null) {
            System.out.println("Account not found.");
            return;
        }
        int attempts = 0;
        boolean isCorrect = false;

        while (attempts < 3) {
            System.out.print("Enter your PIN: ");
            int enteredPin = scanner.nextInt();

            if (enteredPin == account.getPincode()) {
                isCorrect = true;
                break;
            } else {
                attempts++;
                System.out.println("Incorrect! Attempts used: " + attempts + "/3");
            }
        }

        if (isCorrect == false) {
            System.out.println("YOU FRAUD! Access blocked.");
            return;
        }

        System.out.print("Enter amount to withdraw: ");
        double amount = scanner.nextDouble();

        account.withdraw(amount);
        System.out.println("Your balance is: GHS " + account.checkBalance());
    }

    public static void checkBalance(Scanner scanner) {
        System.out.print("Enter Account Number: ");
        scanner.nextLine();
        String accNumber = BankService.readValidString(scanner);

        Account account = BankService.findAccount(accNumber);

        if (account == null) {
            System.out.println("Account not found.");
            return;
        }
        int attempts = 0;
        boolean isCorrect = false;

        while (attempts < 3) {
            System.out.print("Enter your PIN: ");
            int enteredPin = scanner.nextInt();

            if (enteredPin == account.getPincode()) {
                isCorrect = true;
                break;
            } else {
                attempts++;
                System.out.println("Incorrect! Attempts used: " + attempts + "/3");
            }
        }

        if (isCorrect == false) {
            System.out.println("YOU FRAUD! Access blocked.");
            return;
        }

        account.checkBalance();
        System.out.println("Your balance is: GHS " + account.checkBalance());
    }
}
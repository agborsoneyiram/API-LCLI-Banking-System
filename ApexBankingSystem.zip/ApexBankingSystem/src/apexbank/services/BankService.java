package apexbank.services;

import java.util.ArrayList;
import java.util.Scanner;

import apexbank.models.*;

public class BankService {

    private static ArrayList<Account> accounts = new ArrayList<>();


    public static void createAccount(Scanner scanner) {

        scanner.nextLine();

        System.out.print("Enter account holder name: ");
        String name = readValidString(scanner);

        System.out.println("\n--- Select Account Type ---");
        System.out.println("1. Savings Account");
        System.out.println("2. Current Account");
        System.out.print("Select account type (1 or 2): ");

        int accType = readValidInt(scanner);

        System.out.print("Create a 4-digit PIN: ");
        int pin = readValidInt(scanner);

        switch (accType) {

            case 1 -> {
                System.out.print("Enter initial deposit (Minimum GHS50): ");
                double sDeposit;
                while (true) {
                    sDeposit = readValidDouble(scanner);
                    if (sDeposit >= 50)
                        break;
                    else
                        System.out.print("Minimum for Savings is GHS50. Try again: ");
                }
                accounts.add(new SavingsAccount(name, pin, sDeposit));
                System.out.println("Savings Account created successfully!");

                SavingsAccount sa = new SavingsAccount(name, pin, sDeposit);
                accounts.add(sa);
                System.out.println("Success! Your Savings Account Number is: " + sa.getAccountNumber());
            }
            

            case 2 -> {
                System.out.print("Enter initial deposit: ");
                double cDeposit = readValidDouble(scanner);

                CurrentAccount currentAccount =
                        new CurrentAccount(name, pin, cDeposit);

                accounts.add(currentAccount);
                System.out.println("Current Account created successfully!");
                System.out.println("Your Current Account Number is: " + currentAccount.getAccountNumber());
            }

            default -> System.out.println("Invalid account type selected.");
        }
    }

    public static int readValidInt(Scanner scanner) {
        while (!scanner.hasNextInt()) {
            System.out.print("Invalid input. Enter a number: ");
            scanner.next();
        }
        return scanner.nextInt();
    }

    public static double readValidDouble(Scanner scanner) {
        while (!scanner.hasNextDouble()) {
            System.out.print("Invalid amount. Enter a number: ");
            scanner.next();
        }
        return scanner.nextDouble();
    }

    public static String readValidString(Scanner scanner) {
        String input = scanner.nextLine().trim();

        while (input.isEmpty() || input.matches("\\d+")) {
            System.out.print("Invalid name. Enter text: ");
            input = scanner.nextLine().trim();
        }

        return input;
    }

    public static Account findAccount(String searchID) {
    for (Account acc : accounts) {
        
        if (acc.getAccountNumber().equalsIgnoreCase(searchID)) {
            return acc;
        }
    }
    return null;
}

}

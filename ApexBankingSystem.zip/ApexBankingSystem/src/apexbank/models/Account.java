package apexbank.models;

import java.util.*;

public abstract class Account {

    private String accountNumber;
    private String accountHolderName;
    protected int pincode;
    private double balance;
    private List<Transaction> transactions;

    private static int accountCounter = 0;

public Account(String prefix, String name, int pin, double deposit) {
    this.accountHolderName = name;
    this.pincode = pin;
    this.balance = deposit;
    this.transactions = new ArrayList<>();
    
    accountCounter++; 
    this.accountNumber = prefix + String.format("%06d", accountCounter);
}
    public abstract double calculateInterest();

    public double checkBalance() {
        return balance;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            transactions.add(new Transaction(TransactionType.DEPOSIT, amount));
        } else {
            System.out.println("Deposit must be positive.");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            transactions.add(new Transaction(TransactionType.WITHDRAWAL, amount));
        } else {
            System.out.println("Insufficient balance or invalid amount.");
        }
    }

    public void printStatement() {
    System.out.println("--- Mini-Statement for " + accountNumber + " ---");
    int start = Math.max(0, transactions.size() - 5);
    for (int i = start; i < transactions.size(); i++) {
        System.out.println(transactions.get(i).toString());
    }
}
    public String getAccountNumber() {
        return accountNumber;
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public int getPincode() {
        return pincode;
    }
}

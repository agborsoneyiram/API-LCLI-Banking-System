package apexbank.models;

public enum TransactionType {
    DEPOSIT, WITHDRAWAL
}

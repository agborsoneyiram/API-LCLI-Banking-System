package apexbank.models;

import java.time.LocalDateTime;

public class Transaction {

    private double amount;
    private LocalDateTime dateTime;
    private TransactionType type;

    public Transaction(TransactionType type, double amount) {
        this.amount = amount;
        this.type = type;
        this.dateTime = LocalDateTime.now();
    }

    @Override
    public String toString() {
        return String.format("%s: GHS %.2f on %s", type, amount, dateTime.toString());
    }

    public double getAmount() {
        return amount;
    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public TransactionType getType() {
        return type;
    }
}

package apexbank.models;

public class CurrentAccount extends Account {

    private static int currentCounter = 0;
    private static final double INTEREST_RATE = 0.01;

    public CurrentAccount(String name, int pin, double deposit) {
        super("CUR-", name, pin, deposit);
    }

    @Override
    public double calculateInterest() {
        return checkBalance() * INTEREST_RATE;
    }

    public String generateCurrentAccountNumber() {
        currentCounter++;
String prefix = "CUR-";
int min = 100000;
    int max = 999999;
    int uniqueNumber = (int)(Math.random() * (max - min + 1) + min);
    return prefix + uniqueNumber;
    }
}

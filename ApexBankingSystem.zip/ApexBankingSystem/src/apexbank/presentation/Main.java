package apexbank.presentation;
import java.util.Scanner;

import apexbank.services.BankService;
import apexbank.services.UserService;


public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("~WELCOME TO APEX BANKING SYSTEM~");
        
        while (true) {
    System.out.println("\n --------Menu Options-------");
    System.out.println("(1) Create Account");
    System.out.println("(2) Deposit");
    System.out.println("(3) Withdraw");
    System.out.println("(4) Check Balance");
    System.out.println("(5) Print Statement");
    System.out.println("(6) Exit");
    System.out.print("Please select an option (1-6): ");
    
    int choice = scanner.nextInt();

    switch (choice) {
        case 1:
        System.out.println("Creating Account......");
        BankService.createAccount(scanner);
            break;

        case 2:
        System.out.println("Deposit Money......");
        UserService.depositAmount(scanner);
            break;

        case 3:
        System.out.println("Withdraw Money.........");
        UserService.withdrawAmount(scanner);
            break;

        case 4:
        System.out.println("Checking Balance.........");
        UserService.checkBalance(scanner);
            break;

        case 5:
        System.out.println("Printing Statements........");
            break;

        case 6:
        System.out.println("Exiting the system. Goodbye!");
        scanner.close();
        return;

        default:
        System.out.println("Invalid option. Please try again.");
            break;
            
        }
    }
}
}
